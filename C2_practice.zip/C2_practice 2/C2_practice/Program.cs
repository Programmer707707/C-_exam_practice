﻿namespace C2_practice;
class Program
{
    static void Main(string[] args)
    {

        int MAXN = 1000;
        int MAXR = 1000;

        //Input starting
        int N = 0;
        int K = 0;
        int[,] gifts = new int[MAXN + 1, MAXR + 1];

        string input1 = Console.ReadLine();
        if(input1.Length >= 2)
        {
            N = int.Parse(input1.Split(" ")[0]);
            K = int.Parse(input1.Split(" ")[1]);
        }
        for(int i=1; i<=N; i++)
        {
            string[] tmp = Console.ReadLine().Split(" ");
            gifts[i, 0] = int.Parse(tmp[0]);
            for(int j=1; j <= gifts[i,0]; j++)
            {
                gifts[i, j] = int.Parse(tmp[j]);
            }
        }
        //Input ending

        int cnt = 0;

        //Task a - Starting

        for(int i=1; i<=N; i++)
        {
            for(int j=1;  j <= gifts[i,0]; j++)
            {
                if (gifts[i, j] == 10)
                {
                    cnt += 1;
                }
            }
        }
        //Console.WriteLine(cnt);

        // Task a - Ending



        //Task b - Starting
        int sum=0;
  
        int idx=0;
        for (int i = 1; i <= N; i++)
        {
            int temp_sum = 0;
            for (int j = 1; j <= gifts[i, 0]; j++)
            {
                temp_sum += gifts[i, j];
            }

            if(temp_sum > sum)
            {
                sum = temp_sum;
                idx = i;
            }
        }
        //Console.WriteLine(idx);
        //Task b - Ending


        //Task c - Starting
        int c_cnt = 0;
        int[] temp_idxs = new int[MAXN];
        for (int i = 1; i <= N; i++)
        {
            int c_sum = 0;
            for (int j = 1; j <= gifts[i, 0]; j++)
            {
                c_sum += gifts[i, j];
            }

            if (c_sum > K)
            {
                c_cnt++;
                temp_idxs[c_cnt] = i;
               
                
            }
        }

        //Console.Write(c_cnt);
        //for(int i=1; i<=c_cnt; i++)
        //{
        //    Console.Write(" " + temp_idxs[i]);
        //}
        //Console.WriteLine();
        //Task c - Ending


        //Task d - Starting
        int d_min_sum = int.MaxValue;
        for(int i=1; i<=N; i++)
        {
            int d_sum = 0;
            for (int j=1; j <= gifts[i,0]; j++)
            {
                d_sum += gifts[i,j];
            }
            if(d_sum < sum)
            {
                sum = d_sum;
                d_min_sum = d_sum;
            }
        }

        string d_answer = "NO";
        for (int i = 1; i <= N; i++)
        {
            int temp = gifts[i, 1];
            //int cmp_tmp = 0;
            //for (int j = 2; j <= gifts[i, 0]; j++)
            //{
            //    temp = gifts[i, j];
            //}

            //for(int k=1; k <= gifts[i,0]; k++)
            //{
            //    if(temp < gifts[i, k])
            //    {
            //        cmp_tmp = temp;
            //    }
            //}

            for (int j = 2; j <= gifts[i, 0]; j++)
            {
                temp = Math.Min(temp, gifts[i, j]); // Use Math.Min to find the minimum
            }

            if (d_min_sum < temp)
            {
                d_answer = "YES";
            }

        }
        
        Console.WriteLine(d_answer);


    }
}

